package com.github.wenweihu86.raft.example.server.service.impl;

import com.baidu.brpc.client.BrpcProxy;
import com.baidu.brpc.client.RpcClient;
import com.baidu.brpc.client.RpcClientOptions;
import com.baidu.brpc.client.instance.Endpoint;
import com.github.wenweihu86.raft.Peer;
import com.github.wenweihu86.raft.example.server.ExampleStateMachine;
import com.github.wenweihu86.raft.example.server.service.ExampleProto;
import com.github.wenweihu86.raft.example.server.service.ExampleService;
import com.github.wenweihu86.raft.RaftNode;
import com.github.wenweihu86.raft.proto.RaftProto;
import com.googlecode.protobuf.format.JsonFormat;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

/**
 * Created by wenweihu86 on 2017/5/9.
 */
public class ExampleServiceImpl implements ExampleService {

    private static final Logger LOG = LoggerFactory.getLogger(ExampleServiceImpl.class);
    private static JsonFormat jsonFormat = new JsonFormat();

    /*
     * the following two properties should be defined when implementing the interface "ExampleService" 
     */
    private RaftNode raftNode;
    private ExampleStateMachine stateMachine;
    
    private int leaderId = -1;
    private RpcClient leaderRpcClient = null;
    private Lock leaderLock = new ReentrantLock();

    public ExampleServiceImpl(RaftNode raftNode, ExampleStateMachine stateMachine) {
        this.raftNode = raftNode;
        this.stateMachine = stateMachine;
    }

    private void onLeaderChangeEvent() {
            leaderLock.lock();
            if (leaderRpcClient != null) {
                leaderRpcClient.stop();
                leaderRpcClient = null;
            }
            LOG.info("Geting the real leader ID");
            leaderId = raftNode.getLeaderId();
            Peer peer = raftNode.getPeerMap().get(leaderId);
            Endpoint endpoint = new Endpoint(peer.getServer().getEndpoint().getHost(),
                    peer.getServer().getEndpoint().getPort());
            RpcClientOptions rpcClientOptions = new RpcClientOptions();
            rpcClientOptions.setGlobalThreadPoolSharing(true);
            // here, we can reset the Baidu RPC options.
            // remove the following two lines can used the default settings.
            // changed by BOLI
            rpcClientOptions.setSendBufferSize(16*1024*1024);
            rpcClientOptions.setReceiveBufferSize(16*1024*1024);
            rpcClientOptions.setReadTimeoutMillis(2000);
            rpcClientOptions.setWriteTimeoutMillis(2000);
            rpcClientOptions.setConnectTimeoutMillis(360000);
            
            leaderRpcClient = new RpcClient(endpoint, rpcClientOptions);
            leaderLock.unlock();
        
    }

    @Override
    public ExampleProto.SetResponse set(ExampleProto.SetRequest request) {
    	//LOG.info("This node's  leader's ID is: " + raftNode.getLeaderId());
    	//LOG.info("This node's  ID is: " + raftNode.getLocalServer().getServerId());
    	ExampleProto.SetResponse.Builder responseBuilder = ExampleProto.SetResponse.newBuilder();
        // if it is not leader, then redirect the request to the current leader node.
        
        if (raftNode.getLeaderId() <= 0) {
        	LOG.info("raftNode leader ID <=0");
        	//System.out.println("raftNode leader ID <=0");
            responseBuilder.setSuccess(false);
        } else if (raftNode.getLeaderId() != raftNode.getLocalServer().getServerId()) {
        	
        	LOG.info("This connected node is not leader, change to the leader node.");
        	//System.out.println("This connected node is not leader, change to the leader node.");
                    	
        	onLeaderChangeEvent();        	
       	
            ExampleService exampleService = BrpcProxy.getProxy(leaderRpcClient, ExampleService.class);
            ExampleProto.SetResponse responseFromLeader = exampleService.set(request);
            responseBuilder.mergeFrom(responseFromLeader);
        } else {
            // write data to raft cluster simultaneously
        	//LOG.info("The current server is Leader.");
        	//LOG.info("The leaderId is "+ raftNode.getLeaderId() +" and current server's Id is "+ raftNode.getLocalServer().getServerId() );
            byte[] data = request.toByteArray();
            
            //remove the write file to hard disk process Comments:BOLI
            //boolean success = true;
            boolean success = raftNode.replicate(data, request.getValue().length(),RaftProto.EntryType.ENTRY_TYPE_DATA);
            responseBuilder.setSuccess(success);
        }

        ExampleProto.SetResponse response = responseBuilder.build();
        //LOG.info("set request, request={}, response={}", jsonFormat.printToString(request),jsonFormat.printToString(response));
        //LOG.info("request - response correctly finished");
        return response;
    }

    @Override
    /**
     * read data from clusters, will be implemented by the state machine.
     */
    public ExampleProto.GetResponse get(ExampleProto.GetRequest request) {
        ExampleProto.GetResponse response = stateMachine.get(request);
        //LOG.info("get request, request={}, response={}", jsonFormat.printToString(request),jsonFormat.printToString(response));
        return response;
    }

}
