package com.github.wenweihu86.raft.example.server;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;		

import com.baidu.brpc.server.RpcServer;
import com.github.wenweihu86.raft.RaftNode;
import com.github.wenweihu86.raft.RaftOptions;
import com.github.wenweihu86.raft.example.server.service.ExampleService;
import com.github.wenweihu86.raft.example.server.service.impl.ExampleServiceImpl;
import com.github.wenweihu86.raft.proto.RaftProto;
import com.github.wenweihu86.raft.service.RaftClientService;
import com.github.wenweihu86.raft.service.RaftConsensusService;
import com.github.wenweihu86.raft.service.impl.RaftClientServiceImpl;
import com.github.wenweihu86.raft.service.impl.RaftConsensusServiceImpl;
import com.github.wenweihu86.raft.util.ServerList;

/**
 * Created by wenweihu86 on 2017/5/9.
 */
public class ServerMain {
    public static void main(String[] args) throws SQLException {
    	
    	if (args.length != 1) {
            System.out.printf("Usage: ./run_server.sh CURRENT_NODE_ID\n");
            System.exit(-1);
        }
    	String dataPath = "./data";
    	String serversString = ServerList.getServerListWithId();
    	String localServerString = ServerList.getCurrentServerById(Integer.valueOf(args[0]));
    	
    	//System.out.println(serversString);
    	//System.out.println(localServerString);
       	
    	/////  the following are original codes, have been change due to that all parameters are read from database ////////
        //if (args.length != 3) {
        //    System.out.printf("Usage: ./run_server.sh DATA_PATH CLUSTER CURRENT_NODE\n");
        //     System.exit(-1);
        // }
        // parse args
        // raft data dir
        //String dataPath = args[0];
        // peers, format is "host:port:serverId,host2:port2:serverId2"
        //String servers = args[1];
        //remove the "list://" in Linux command line.
        //servers = servers.replace("list://", "");
        //String[] splitArray = servers.split(",");
        String[] splitArray = serversString.split(",");
        List<RaftProto.Server> serverList = new ArrayList<>();
        for (String serverString : splitArray) {
            RaftProto.Server server = parseServer(serverString);
            serverList.add(server);
        }
        // local server
        //RaftProto.Server localServer = parseServer(args[2]);
        RaftProto.Server localServer = parseServer(localServerString);
        
        
        //Initialize the RPCServer
        RpcServer server = new RpcServer(localServer.getEndpoint().getPort());
        // Set up Raft选项，比如：
        // just for test snapshot
        RaftOptions raftOptions = new RaftOptions();
        raftOptions.setDataDir(dataPath);
        // remove the following settings and read it from file when creating a new RaftOptions object.
        //raftOptions.setSnapshotMinLogSize(100*1024 * 1024);
        // raftOptions.setSnapshotPeriodSeconds(3600);
        // raftOptions.setMaxSegmentFileSize(1000*1024 * 1024);
        
        //applying the state machine
        ExampleStateMachine stateMachine = new ExampleStateMachine(raftOptions.getDataDir());
        
        // initilize RaftNode
        RaftNode raftNode = new RaftNode(raftOptions, serverList, localServer, stateMachine);
        // register Raft节点之间相互调用的服务
        RaftConsensusService raftConsensusService = new RaftConsensusServiceImpl(raftNode);
        server.registerService(raftConsensusService);
        //register the Raft service for the Client调用
        RaftClientService raftClientService = new RaftClientServiceImpl(raftNode);
        server.registerService(raftClientService);
        // register the service that the application used for itself
        ExampleService exampleService = new ExampleServiceImpl(raftNode, stateMachine);
        server.registerService(exampleService);
        //Start up the RPCServer
        server.start();
        // initialize the Raft node
        raftNode.init();
    }

    private static RaftProto.Server parseServer(String serverString) {
        String[] splitServer = serverString.split(":");
        String host = splitServer[0];
        Integer port = Integer.parseInt(splitServer[1]);
        Integer serverId = Integer.parseInt(splitServer[2]);
        RaftProto.Endpoint endPoint = RaftProto.Endpoint.newBuilder()
                .setHost(host).setPort(port).build();
        RaftProto.Server.Builder serverBuilder = RaftProto.Server.newBuilder();
        RaftProto.Server server = serverBuilder.setServerId(serverId).setEndpoint(endPoint).build();
        return server;
    }
}
